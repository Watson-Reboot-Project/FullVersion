## Watson Reboot - Database lab

not sure what i'm doing yet.
